from django.shortcuts import render
from .models import Task
from django.views.generic import ListView, CreateView, UpdateView, DetailView, DeleteView
from .forms import Createform
from django.urls import reverse_lazy

# Create your views here.
class Tasklist(ListView):
    model = Task
    template_name = 'showtask.html'
    context_object_name = 'taskobject'

class Createtask(CreateView):
    model = Task
    form_class = Createform
    template_name = 'createtask.html'
    success_url = reverse_lazy('tasklist')

class Updatetask(UpdateView):
    model = Task
    form_class = Createform
    template_name = 'updatetask.html'
    success_url = reverse_lazy('tasklist')

class Viewtask(DetailView):
    model = Task
    template_name = 'viewtask.html'
    context_object_name = 'i'
